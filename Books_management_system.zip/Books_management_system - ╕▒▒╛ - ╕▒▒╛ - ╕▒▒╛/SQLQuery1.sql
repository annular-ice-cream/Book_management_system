﻿alter database[C:\USERS\ADMINISTRATOR\DOCUMENTS\SHUDUODUOSHOPDB.MDF] set single_user with rollback immediate;
alter database[C:\USERS\ADMINISTRATOR\DOCUMENTS\SHUDUODUOSHOPDB.MDF] collate Chinese_PRC_CI_AS;
alter database[C:\USERS\ADMINISTRATOR\DOCUMENTS\SHUDUODUOSHOPDB.MDF] set multi_user;