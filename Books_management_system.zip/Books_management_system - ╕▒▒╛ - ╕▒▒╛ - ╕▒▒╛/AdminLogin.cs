﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Books_management_system
{
    public partial class AdminLogin : Form
    {
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//登录
        {
            if(UPassTb.Text == "password")
            {
                books obj = new books();
                obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("密码错误！！");
            }
        }

        private void label3_Click(object sender, EventArgs e)//返回
        {
            login obj = new login();
            obj.Show();
            this.Hide();
        }
    }
}
